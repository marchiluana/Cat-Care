These are files that are not currently in use either because I have not 
finished them or a better version was created. I'm including them here
for anyone who prefers the old format